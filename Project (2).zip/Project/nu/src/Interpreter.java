import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class Interpreter {
    private Map<String, Integer> variables = new HashMap<>();

    public void interpret(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                execute(parse(line));
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            System.exit(1);
        }
    }

    private Token parse(String line) {
        String[] tokens = line.split("\\s+");
        if (tokens.length < 1) {
            throw new IllegalArgumentException("Invalid syntax: empty line");
        }

        switch (tokens[0]) {
            case "function":
                if (tokens.length < 2) {
                    throw new IllegalArgumentException("Invalid syntax: " + line);
                }
                return new FunctionToken(tokens[1]);
            case "if":
                if (tokens.length != 4 || !tokens[2].equals("~=")) {
                    throw new IllegalArgumentException("Invalid syntax: " + line);
                }
                return new IfToken(tokens[1], tokens[3]);
            case "print":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("Invalid syntax: " + line);
                }
                return new PrintToken(tokens[1]);
            case "=":
                if (tokens.length != 3) {
                    throw new IllegalArgumentException("Invalid syntax: " + line);
                }
                return new AssignmentToken(tokens[1], tokens[2]);
            default:
                throw new IllegalArgumentException("Invalid syntax: " + line);
        }
    }

    private void execute(Token token) {
        if (token instanceof FunctionToken) {
            FunctionToken functionToken = (FunctionToken) token;
            // Do nothing for now
        } else if (token instanceof IfToken) {
            IfToken ifToken = (IfToken) token;
            if (!ifToken.condition.equals(variables.get(ifToken.variable))) {
                return;
            }
        } else if (token instanceof PrintToken) {
            PrintToken printToken = (PrintToken) token;
            Integer value = variables.get(printToken.variable);
            if (value == null) {
                System.err.println("Error: variable " + printToken.variable + " not defined");
                return;
            } else {
                System.out.println(value);
            }
        } else if (token instanceof AssignmentToken) {
            AssignmentToken assignmentToken = (AssignmentToken) token;
            variables.put(assignmentToken.variable, Integer.parseInt(assignmentToken.value));
        } else {
            throw new IllegalArgumentException("Invalid token: " + token);
        }
    }

    private static abstract class Token {
    }

    private static class FunctionToken extends Token {
        public String name;

        public FunctionToken(String name) {
            this.name = name;
        }
    }

    private static class IfToken extends Token {
        public String variable;
        public String condition;

        public IfToken(String variable, String condition) {
            this.variable = variable;
            this.condition = condition;
        }
    }

    private static class PrintToken extends Token {
        public String variable;

        public PrintToken(String variable) {
            this.variable = variable;
        }
    }

    private static class AssignmentToken extends Token {
        public String variable;
        public String value;

        public AssignmentToken(String variable, String value) {
            this.variable = variable;
            this.value = value;
        }
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("");
            System.exit(1);
        }

        Interpreter interpreter = new Interpreter();
        interpreter.interpret("\"C:\\Users\\Syednoraiz\\Downloads\\Project\\nu\\src\\Test3.jl\"");

    }
}