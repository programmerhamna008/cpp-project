//Test 3 in Julia

function a()
	x = 1
		if ~= x 1 then
			print(0)
		else
			print(1)
		end
end