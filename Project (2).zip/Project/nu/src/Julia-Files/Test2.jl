//test 2 in julia
function a()
	x = 1
	while <x 4 do
		x += x 1
	end
	print(x)
end