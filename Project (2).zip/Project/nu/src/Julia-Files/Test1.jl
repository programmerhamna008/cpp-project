// review  https://replit.com/languages/julia  there are issues in Test2.jl and Test3.jl

//Test 1 in Julia
function a()
	x = 1
		print(x)
		
		
		
end