import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Token {
    private String type;
    private String value;

    public Token(){
        type = "";
        value = "";
    }
    public Token(String type, String value) {
        this.type = type;
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public String getValue() {
        return value;
    }
    public void setType(String type) {
        this.type = type;
    }

    public void setValue(String value) {
        this.value = value;
    }

    // Define a regular expression that matches valid tokens
    private static final String TOKEN_REGEX = "^[a-zA-Z_]\\w*$";

    public static void main(String[] args) {
        // Call the scanFile function with the filename "Test1.jl" and print the result
        ArrayList<String> tokens = scanFile("Test1.jl");
        System.out.println(tokens);
    }

    // Define a function that reads a file and returns a list of tokens
    public static ArrayList<String> scanFile(String filename) {
        // Define the list of tokens
        ArrayList<String> tokens = new ArrayList<String>();
        // Open the file
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            // Loop over each line in the file
            while ((line = reader.readLine()) != null) {
                // Split the line into words
                String[] words = line.split("\\s+");
                // Loop over each word
                for (String word : words) {
                    // Check if the word is a valid token
                    if (isValidToken(word)) {
                        // Add the token to the list
                        tokens.add(word);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Return the list of tokens
        return tokens;
    }

    // Define a function that checks if a word is a valid token
    public static boolean isValidToken(String word) {
        // Define a pattern that matches the regular expression
        Pattern pattern = Pattern.compile(TOKEN_REGEX);
        // Match the pattern against the word
        Matcher matcher = pattern.matcher(word);
        // Check if the word matches the pattern
        return matcher.matches();
    }
}