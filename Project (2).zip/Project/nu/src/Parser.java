/*
 * Class:       CS 4308 Section #
 * Term:        Spring
 * Name:       <Christian Robertson>
 * Instructor:  Sharon Perry
 * Project:      Deliverable P2 Parser
 */
public class Parser {
    private Scanner scanner;
    private Token currentToken;

    public Parser(String fileName) {
        scanner = new Scanner(fileName);
        currentToken = scanner.nextToken();
    }

    public void parse() {
        while (!scanner.isEoFile()) {
            statement();
        }
    }

    private void statement() {
        if (currentToken.getType().equals("Keyword")) {
            switch (currentToken.getValue().toLowerCase()) {
                case "function":
                    functionDeclaration();
                    break;
                case "while":
                    whileLoop();
                    break;
                case "if":
                    ifStatement();
                    break;
                default:
                    System.out.println("Unrecognized statement: " + currentToken.getValue());
                    currentToken = scanner.nextToken();
                    break;
            }
        } else if (currentToken.getType().equals("Identifier") || currentToken.getType().equals("Operator")) {
            assignmentOrFunctionCall();
        } else {
            System.out.println("Unrecognized statement: " + currentToken.getValue());
            currentToken = scanner.nextToken();
        }
    }
    private void functionDeclaration() {
        System.out.println("Recognized statement: function declaration");
        currentToken = scanner.nextToken(); // Consume 'function' keyword

        if (currentToken.getType().equals("Identifier")) {
            currentToken = scanner.nextToken(); // Consume function name
        }

        if (currentToken.getType().equals("Separator") && currentToken.getValue().equals("(")) {
            currentToken = scanner.nextToken(); // Consume '('

            while (!currentToken.getValue().equals(")")) {
                currentToken = scanner.nextToken(); // Consume function parameters
            }

            currentToken = scanner.nextToken(); // Consume ')'
        }
    }

    private void assignmentOrFunctionCall() {
        String identifier = currentToken.getValue();
        currentToken = scanner.nextToken(); // Consume identifier

        if (currentToken.getType().equals("Operator") && currentToken.getValue().equals("=")) {
            System.out.println("Recognized statement: variable assignment");
            currentToken = scanner.nextToken(); // Consume '='
            currentToken = scanner.nextToken(); // Consume value
        } else if (currentToken.getType().equals("Separator") && currentToken.getValue().equals("(")) {
            System.out.println("Recognized statement: function call");
            currentToken = scanner.nextToken(); // Consume '('

            while (!currentToken.getValue().equals(")")) {
                currentToken = scanner.nextToken(); // Consume function arguments
            }

            currentToken = scanner.nextToken(); // Consume ')'
        } else {
            System.out.println("Unrecognized statement: " + identifier);
        }
    }
    private void whileLoop() {
        System.out.println("Recognized statement: while loop");
        currentToken = scanner.nextToken(); // Consume 'while'

        expression(); // Parse the expression

        if (currentToken.getValue().equalsIgnoreCase("do")) {
            currentToken = scanner.nextToken(); // Consume 'do'

            while (!currentToken.getValue().equalsIgnoreCase("end")) {
                statement(); // Parse statements inside the while loop
            }

            currentToken = scanner.nextToken(); // Consume 'end'
        }
    }

    private void ifStatement() {
        System.out.println("Recognized statement: if statement");
        currentToken = scanner.nextToken(); // Consume 'if'

        expression(); // Parse the expression

        if (currentToken.getValue().equalsIgnoreCase("then")) {
            currentToken = scanner.nextToken(); // Consume 'then'

            while (!currentToken.getValue().equalsIgnoreCase("end")) {
                statement(); // Parse statements inside the if statement
            }

            currentToken = scanner.nextToken(); // Consume 'end'
        }
    }
    private void expression() {
        boolean inCompoundExpression = false;
        while (!currentToken.getType().equals("Keyword") && !currentToken.getValue().equals(";") && !currentToken.getValue().equalsIgnoreCase("do") && !currentToken.getValue().equalsIgnoreCase("then")) {
            switch (currentToken.getType()) {
                case "Identifier":
                    System.out.println("Recognized identifier: " + currentToken.getValue());
                    break;
                case "Literal":
                    System.out.println("Recognized number: " + currentToken.getValue());
                    break;
                case "Operator":
                    if (currentToken.getValue().equals("+") || currentToken.getValue().equals("=")) {
                        inCompoundExpression = true;
                    }
                    System.out.println("Recognized operator: " + currentToken.getValue());
                    break;
                default:
                    System.out.println("Unrecognized expression element: " + currentToken.getValue());
                    break;
            }
            currentToken = scanner.nextToken(); // Consume tokens in the expression
        }

        if (inCompoundExpression) {
            System.out.println("Recognized statement: compound expression");
        }
    }

    public static void main(String[] args) {
        Parser parser = new Parser("\"C:\\Users\\Syednoraiz\\Downloads\\Project\\nu\\src\\Test3.jl\"");
        parser.parse();
    }
}